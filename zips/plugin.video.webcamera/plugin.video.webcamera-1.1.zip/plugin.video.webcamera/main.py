# -*- coding: UTF-8 -*-
import urllib, urllib2, re, xbmc, xbmcplugin, xbmcgui, xbmc, xbmcaddon, HTMLParser, os
import requests
from resources.lib.libraries import source_utils, dom_parser, client, cleantitle
import sys  
reload(sys)  
sys.setdefaultencoding('utf8')
#=########################################################################################################=#
#                                                   MENU                                                   #
#=########################################################################################################=#
def CATEGORIES():
    addDir('[B]############## Kategorie ##############[/B]', '-', None, 'search.jpg','', False)
    addDir('Plaża i morze', '-', 3, 'search.jpg','', True)
    addDir('Miasta', '-', 3, 'search.jpg','', True)
    addDir('Góry', '-', 3, 'search.jpg','', True)
    addDir('Gniazda bocianie/Karmniki', '-', 3, 'search.jpg','', True)
    addDir('Lodowiska', '-', 3, 'search.jpg','', True)
###################################################################################
#=########################################################################################################=#
#                                                 FUNCTIONS                                                #
#=########################################################################################################=#
def mySearch():
    keyb = xbmc.Keyboard('', 'XBMC Search')
    keyb.doModal()
    if keyb.isConfirmed() and len(keyb.getText().strip()) > 0 :
        search = keyb.getText()
        myParam = str(urllib.quote(search)).strip()
        addDir(myParam, 'myUrl', 2, 'other.jpg', False)
    else:
        CATEGORIES()
    
def myOther():
    dialog = xbmcgui.Dialog()
    ok = dialog.ok('XBMC', 'Hello World')
    
def addDir(name, url, mode, iconimage,thumb, isFolder=True, total=1):
    u=sys.argv[0]+'?url='+urllib.quote_plus(url)+'&mode='+str(mode)+'&name='+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    url = thumb
    liz.setArt({'thumb': url,
                'icon': url,
                'fanart': url})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder, totalItems=total)
    return ok
###################################################################################
#=########################################################################################################=#
#                                               GET PARAMS                                                 #
#=########################################################################################################=#    
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2 :
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/') :
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)) :
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]                  
    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
    url = urllib.unquote_plus(params['url'])
except:
    pass
try:
    name = urllib.unquote_plus(params['name'])
except:
    pass
try:
    mode = int(params['mode'])
except:
    pass
try:        
    iconimage = urllib.unquote_plus(params['iconimage'])
except:
    pass


################################MENU###########################
if name == 'Plaża i morze' and mode == 3:
    lista_linkow = []
    lista_tytulow = []
    import requests
    from bs4 import BeautifulSoup
    import json
    
    cookies = {
        'asudifg7a8wg487g': '2is7ii7m7js7r0lpqfihkfi2e0',
    }
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Host': 'www.webcamera.pl',
        'Referer': 'https://www.webcamera.pl/kategoria,plaze-i-morze',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    params = (
        ('page', '0'),
        ('limit', '1000'),
        ('type', 'category'),
        ('id', '16')
    )
    
    response = requests.get('https://www.webcamera.pl/ajax/getNextListItems.php', headers=headers, params=params, cookies=cookies)
    response.encoding = 'utf-8'
    k = BeautifulSoup(json.loads(response.text)['html'], 'html.parser')
    addDir('[B]Linki potrzebuja 10 sekund do zaladowania![/B]', '', 10, '','', False)
    for content in k.contents:
        lista_linkow.append(content.contents[1].attrs[u'href'].replace('//','http://'))
        lista_tytulow.append(content.contents[1].attrs[u'title'].replace('Przejdź do kamery ',''))
        image = content.contents[1].contents[3].attrs[u'data-src'].replace('//','http://')
        addDir(str(lista_tytulow[-1]), lista_linkow[-1], 10, '',image, False)
        
if name == 'Miasta' and mode == 3:
    lista_linkow = []
    lista_tytulow = []
    import requests
    from bs4 import BeautifulSoup
    import json
    
    cookies = {
        'asudifg7a8wg487g': '2is7ii7m7js7r0lpqfihkfi2e0',
    }
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Host': 'www.webcamera.pl',
        'Referer': 'https://www.webcamera.pl/kategoria,miasta',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    params = (
        ('page', '0'),
        ('limit', '1000'),
        ('type', 'category'),
        ('id', '5')
    )
    
    response = requests.get('https://www.webcamera.pl/ajax/getNextListItems.php', headers=headers, params=params, cookies=cookies)
    response.encoding = 'utf-8'
    k = BeautifulSoup(json.loads(response.text)['html'], 'html.parser')
    addDir('[B]Linki potrzebuja 10 sekund do zaladowania![/B]', '', 10, '','', False)
    for content in k.contents:
        lista_linkow.append(content.contents[1].attrs[u'href'].replace('//','http://'))
        lista_tytulow.append(content.contents[1].attrs[u'title'].replace('Przejdź do kamery ',''))
        image = content.contents[1].contents[3].attrs[u'data-src'].replace('//','http://')
        addDir(str(lista_tytulow[-1]), lista_linkow[-1], 10, '',image, False)

if name == 'Góry' and mode == 3:
    lista_linkow = []
    lista_tytulow = []
    import requests
    from bs4 import BeautifulSoup
    import json
    
    cookies = {
        'asudifg7a8wg487g': '2is7ii7m7js7r0lpqfihkfi2e0',
    }
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Host': 'www.webcamera.pl',
        'Referer': 'https://www.webcamera.pl/kategoria,gory',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    params = (
        ('page', '0'),
        ('limit', '1000'),
        ('type', 'category'),
        ('id', '15')
    )
    
    response = requests.get('https://www.webcamera.pl/ajax/getNextListItems.php', headers=headers, params=params, cookies=cookies)
    response.encoding = 'utf-8'
    k = BeautifulSoup(json.loads(response.text)['html'], 'html.parser')
    addDir('[B]Linki potrzebuja 10 sekund do zaladowania![/B]', '', 10, '','', False)
    for content in k.contents:
        lista_linkow.append(content.contents[1].attrs[u'href'].replace('//','http://'))
        lista_tytulow.append(content.contents[1].attrs[u'title'].replace('Przejdź do kamery ',''))
        image = content.contents[1].contents[3].attrs[u'data-src'].replace('//','http://')
        addDir(str(lista_tytulow[-1]), lista_linkow[-1], 10, '',image, False)

if name == 'Lodowiska' and mode == 3:
    lista_linkow = []
    lista_tytulow = []
    import requests
    from bs4 import BeautifulSoup
    import json
    
    cookies = {
        'asudifg7a8wg487g': '2is7ii7m7js7r0lpqfihkfi2e0',
    }
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Host': 'www.webcamera.pl',
        'Referer': 'https://www.webcamera.pl/kategoria,lodowiska',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    params = (
        ('page', '0'),
        ('limit', '1000'),
        ('type', 'category'),
        ('id', '41')
    )
    
    response = requests.get('https://www.webcamera.pl/ajax/getNextListItems.php', headers=headers, params=params, cookies=cookies)
    response.encoding = 'utf-8'
    k = BeautifulSoup(json.loads(response.text)['html'], 'html.parser')
    addDir('[B]Linki potrzebuja 10 sekund do zaladowania![/B]', '', 10, '','', False)
    for content in k.contents:
        lista_linkow.append(content.contents[1].attrs[u'href'].replace('//','http://'))
        lista_tytulow.append(content.contents[1].attrs[u'title'].replace('Przejdź do kamery ',''))
        image = content.contents[1].contents[3].attrs[u'data-src'].replace('//','http://')
        addDir(str(lista_tytulow[-1]), lista_linkow[-1], 10, '',image, False)
        
if name == 'Gniazda bocianie/Karmniki' and mode == 3:
    lista_linkow = []
    lista_tytulow = []
    import requests
    from bs4 import BeautifulSoup
    import json
    
    cookies = {
        'asudifg7a8wg487g': '2is7ii7m7js7r0lpqfihkfi2e0',
    }
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Host': 'www.webcamera.pl',
        'Referer': 'https://www.webcamera.pl/kategoria,lodowiska',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    params = (
        ('page', '0'),
        ('limit', '1000'),
        ('type', 'category'),
        ('id', '44')
    )
    
    response = requests.get('https://www.webcamera.pl/ajax/getNextListItems.php', headers=headers, params=params, cookies=cookies)
    response.encoding = 'utf-8'
    k = BeautifulSoup(json.loads(response.text)['html'], 'html.parser')
    addDir('[B]Linki potrzebuja 10 sekund do zaladowania![/B]', '', 10, '','', False)
    for content in k.contents:
        lista_linkow.append(content.contents[1].attrs[u'href'].replace('//','http://'))
        lista_tytulow.append(content.contents[1].attrs[u'title'].replace('Przejdź do kamery ',''))
        image = content.contents[1].contents[3].attrs[u'data-src'].replace('//','http://')
        addDir(str(lista_tytulow[-1]), lista_linkow[-1], 10, '',image, False)

###################################################################################
#=###########################################################################################################=#
#                                                   MODES                                                     #
#=###########################################################################################################=#
if mode == None or url == None or len(url) < 1 :
    CATEGORIES()
elif mode == 1 :
    mySearch()
elif mode == 2 :
    myOther()
elif mode == 10 :
    name = urllib.unquote_plus(params['name'])
    url = urllib.unquote_plus(params['url'])
    response = requests.get(url)
    response.encoding = 'utf-8'
    result = response.text
    result = client.parseDOM(result, 'iframe', ret='src')
    url = result[1].replace('//','http://')
    response = requests.get(url)
    response.encoding = 'utf-8'
    result = response.text
    index = result.find("var hlspath = '")
    result = result[index+15:]
    index = result.find("';")
    result = result[:index]
    
    from string import maketrans   # Required to call maketrans function.

    intab = "abcdefghijklmnopqrstuvwxyz"
    outtab = "nopqrstuvwxyzabcdefghijklm"
    trantab = maketrans(intab, outtab)
    
    str = str(result)
    
    url = str.translate(trantab)
    
    url = url.replace('//', 'http://')
    xbmc.Player().play(url)
###################################################################################
xbmcplugin.endOfDirectory(int(sys.argv[1]))