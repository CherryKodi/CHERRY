# -*- coding: utf-8 -*-

import urllib2,urllib,json
import re,os
import urlparse


BASEURL= "http://lech.tv"
TIMEOUT = 10
UA='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
iteppp=25

def getUrl(url,data=None,cookies=None):

    req = urllib2.Request(url,data)
    req.add_header('User-Agent', UA)
    if cookies:
        req.add_header("Cookie", cookies)
    try:
        response = urllib2.urlopen(req,timeout=TIMEOUT)
        link = response.read()
        response.close()
    except:
        link=''
    return link

def getContent(url,type='category',page=1,category=7,**args):
    if type == 'category':
        url='http://lech.tv/lechtv_ajax/get_videos_category.php'
        data='video_start_number=%d&video_stop_number=%d&category_id=%d'%(int(page)*iteppp,iteppp,int(category))
    elif type== 'popular':
        url='http://lech.tv/lechtv_ajax/get_videos_most_popular.php'
        data=''
    else:
        url='http://lech.tv/lechtv_ajax/get_videos_newest.php'
        data='video_start_number=%d&video_stop_number=%d'%(int(page)*iteppp,iteppp)

    content = getUrl(url,data)
    out = parseContent(content)
    
    nextPage = {'type':type,'page':int(page)+1,'category':category} if len(out) == iteppp else False
    prevPage = {'type':type,'page':int(page)-1,'category':category} if int(page)>0 else False
    return out,(prevPage,nextPage)
    

    
def parseContent(content):    
    content = content.decode('unicode_escape')
    ids = [(a.start(), a.end()) for a in re.finditer('<td class="video_medium_box">', content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        #print content[ ids[i][1]:ids[i+1][0] ]
        subset = content[ ids[i][1]:ids[i+1][0] ].replace('\\','').encode('utf-8')
        img = re.compile('<img src="(.*?)" alt=".*?"').findall(subset)
        href = re.compile('<a href="video-id-(\d+)-.*?"').findall(subset)
        #title = re.compile('<a href=".*?" class="video_medium_title">(.*?)</a>').findall(subset)
        title = re.compile('<img src=".*?" alt="(.*?)"').findall(subset)
        plot = re.compile('<a href=".*?" class="video_medium_desc_short">(.*?)</a>').findall(subset)
        code = re.compile('<span class="video_medium_date">(.*?)</span>').findall(subset)
        if not code:
            code = re.compile('<a href=".*?" class="video_medium_category">(.*?)</a>').findall(subset)
    
        if href and title:
            h = href[0]
            t = unicodePLchar(title[0].strip())
            i = urlparse.urljoin(BASEURL,img[0]) if img else ''
            p = unicodePLchar(plot[0].strip()) if plot else ''
            c = unicodePLchar(code[0].strip()) if code else ''
            out.append({'url':h,'title':t,'img':i,'plot':p,'code':c})
    return out

def tabela_ekstraklasy():
    content= getUrl(BASEURL)
    tabela = re.compile('<table class="league_table">(.*?)</table>',re.DOTALL).findall(content)
    out = []
    if tabela:
        pos = re.compile('<td class="league_table_position">(.+?)<').findall(tabela[0])
        pts = re.compile('<td class="league_table_points">(.+?)<').findall(tabela[0])
        team = re.compile('<td class="league_table_team">(.+?)<').findall(tabela[0])
        for p,pt,name in zip(pos,pts,team):
            out.append({'title':'%s [B]%s[/B]'%(p,name),'code':'[COLOR blue][B]%s[/B][/COLOR]'%pt})
    return out

def getVideos(id='23422'):
    url='http://lech.tv/lechtv_ajax/get_player_new.php'
    data='id='+id+'&ads_param='
    content = getUrl(url,data)
    video_url={'msg':'Video link not found or not supported yet'}
    src = re.compile('src=["\'](.*?)["\']').findall(content)
    if src:
        data = getUrl(src[0])
        srcs=re.compile('src\s*=\s*\[\s*\[(.*?)\]\s*\];',re.DOTALL).findall(data)
        if srcs:
            links=re.compile('"(http.*?)"').findall(srcs[0])
            for link in links:
                if link.endswith('.m3u8') or link.endswith('.mp4'):
                    video_url={'msg':'','url':link,'resolved':True}
                    break
    return video_url

def getMain():
    out=[
        {'title':'Nowe','url':'','params':{'type':'newest','page':0}},
        {'title':'Popularne','url':'','params':{'type':'popular','page':0}},
        {'title':'Pierwsza Drużyna','url':'','params':{'type':'category','page':'0','category':'3'}},
        {'title':'Skróty Meczów','url':'','params':{'type':'category','page':'0','category':'7'}},
        {'title':'Wywiady','url':'','params':{'type':'category','page':'0','category':'1'}},
        {'title':'Konferencje Prasowe','url':'','params':{'type':'category','page':'0','category':'2'}},
        {'title':'Rezerwy','url':'','params':{'type':'category','page':'0','category':'4'}},
        {'title':'Akademia','url':'','params':{'type':'category','page':'0','category':'5'}},
        {'title':'Oldboje','url':'','params':{'type':'category','page':'0','category':'6'}},
        ]
    return out

    
def unicodePLchar(txt):
    txt = txt.replace('#038;','')
    txt = txt.replace('&lt;br/&gt;',' ')
    txt = txt.replace('&#34;','"')
    txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    txt = txt.replace('&#8221;','"')
    txt = txt.replace('&#8222;','"')
    txt = txt.replace('&#8217;','\'')
    txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    txt = txt.replace('&amp;','&')
    txt = txt.replace('\u0105','ą').replace('\u0104','Ą')
    txt = txt.replace('\u0107','ć').replace('\u0106','Ć')
    txt = txt.replace('\u0119','ę').replace('\u0118','Ę')
    txt = txt.replace('\u0142','ł').replace('\u0141','Ł')
    txt = txt.replace('\u0144','ń').replace('\u0144','Ń')
    txt = txt.replace('\u00f3','ó').replace('\u00d3','Ó')
    txt = txt.replace('\u015b','ś').replace('\u015a','Ś')
    txt = txt.replace('\u017a','ź').replace('\u0179','Ź')
    txt = txt.replace('\u017c','ż').replace('\u017b','Ż')
    return txt